# BabyCare – Free Bootstrap 5 Educational Website Template

#### Preview

 - [Demo](https://themewagon.github.io/BabyCare/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/babycare/)
 
 
## Getting Started

Clone from GitHub 
```
https://github.com/themewagon/BabyCare.git
```

## Author

Design and code are completely written by HTML Codex's design and development team.  


## License

 - Design and Code is Copyright &copy; [HTML Codex](https://htmlcodex.com/)
 - Licensed under [MIT]
 - Distributed by [ThemeWagon](https://themewagon.com)


